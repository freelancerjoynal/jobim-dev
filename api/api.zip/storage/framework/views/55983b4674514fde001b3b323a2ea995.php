<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto p-4">
        <!-- Page Title -->
        <h1 class="text-2xl font-bold mb-4">Professions</h1>

        <!-- Display Flash Messages -->
        <?php if(session('success')): ?>
            <div class="bg-green-100 text-green-800 border border-green-300 rounded-lg p-4 mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php elseif(session('error')): ?>
            <div class="bg-red-100 text-red-800 border border-red-300 rounded-lg p-4 mb-4">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <!-- Add Profession Form -->
        <div class="mb-6 bg-white shadow-md rounded-lg p-6">
            <form action="<?php echo e(route('create.professions')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="flex items-center">
                    <div class="w-full mr-4">
                        <label for="profession" class="block text-sm font-medium text-gray-700 text-right">New Profession</label>
                        <input type="text" id="profession" name="profession" class="input input-bordered w-full text-right" placeholder="Enter profession" required>
                    </div>
                    <div>
                        <button type="submit" class="btn btn-primary mt-6">Add Profession</button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Professions Table -->
        <div class="overflow-x-auto bg-white shadow-md rounded-lg p-6">
            <table class="table w-full text-right">
                <thead class="bg-gray-200">
                    <tr>         
                        <th class="py-2 px-4 text-left">Action</th>
                        <th class="py-2 px-4 text-left">Profession</th>
                        <th class="py-2 px-4 text-left">S.N</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(isset($professions)): ?>
                        <?php
                            $serial = 1;
                        ?>
                        <?php $__currentLoopData = $professions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-100">
                               
                                
                                <td class="py-2 px-4">
                                    <a href="<?php echo e(route('professions.delete', ['id' => $item->profession_id])); ?>" 
                                       class="btn btn-sm btn-error" 
                                       onclick="return confirm('Are you sure you want to delete this profession?')">Delete</a>
                                </td>
                                <td class="py-2 px-4"><?php echo e($item->profession_name); ?></td>
                                <td class="py-2 px-4"><?php echo e($serial); ?></td>
                            </tr>
                            <?php
                                $serial = $serial + 1;
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\CLIENT_PROJECTS\jobim\api\resources\views/professions/professions.blade.php ENDPATH**/ ?>