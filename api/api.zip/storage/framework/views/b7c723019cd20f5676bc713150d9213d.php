<div class="all-jobs">
    <div class="bg-white shadow-md rounded-lg p-6">
        <table id="allposts" class="display min-w-full text-right">
            <thead class="bg-gray-200">
                <tr>
                    <th class="py-2 px-4">Action</th>
                    <th class="py-2 px-4">Description</th>
                    <th class="py-2 px-4">Profession</th>
                    <th class="py-2 px-4">Image</th>
                    <th class="py-2 px-4">Publisher</th>
                    <th class="py-2 px-4">S.N</th>
                </tr>
            </thead>
            <tbody>
                <?php if(isset($jobPosts)): ?>
                <?php
                    $serial = 1;
                ?>
                    <?php $__currentLoopData = $jobPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <form action="<?php echo e(route('job-posts.destroy', $item->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this job post?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-xs btn-error">X</button>
                            </form>
                        </td>
                        <td><?php echo e(\Illuminate\Support\Str::words($item->description, 15, '...')); ?></td>
                        <td><?php echo e($item->profession); ?></td>
                        <td>
                            <?php if($item->imagepost !== null): ?>
                                <img src="<?php echo e(asset('/') . $item->imagepost); ?>" class="w-full max-w-20" alt="No image for this job">
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($item->publisher); ?></td>
                        <td><?php echo e($serial); ?></td>
                    </tr>
                    <?php
                        $serial++;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function() {
        $('#allposts').DataTable();
    });
</script>
<?php /**PATH D:\CLIENT_PROJECTS\jobim\api\resources\views/alljobs/alljobs.blade.php ENDPATH**/ ?>